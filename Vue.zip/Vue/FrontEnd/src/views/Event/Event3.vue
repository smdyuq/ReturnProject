<template>
    <div class="eventThirdPage">
        이벤트3 페이지
    </div>
</template>

<script>
export default {
    
}
</script>
<style>
.eventThirdPage {
    width:1024px;
    height:900px;
    background-color:skyblue;
}
</style>