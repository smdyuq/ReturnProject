<template>
    <div class="eventFirstPage">
        이벤트1 페이지
    </div>
</template>

<script>
export default {
    
}
</script>
<style>
.eventFirstPage {
    width:1024px;
    height:900px;
    background-color:gray;
}
</style>