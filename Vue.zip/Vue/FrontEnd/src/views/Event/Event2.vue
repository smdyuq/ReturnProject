<template>
    <div class="eventSecondPage">
        이벤트2 페이지
    </div>
</template>

<script>
export default {
    
}
</script>
<style>
.eventSecondPage {
    width:1024px;
    height:900px;
    background-color:antiquewhite;
}
</style>