<template>
    <div>
        <div>
            <span>홈 > </span>
            <select v-model="selectedCategory" @change="handleCategoryChange">
                <option>전체</option>
                <option>의류</option>
                <option>주얼리</option>
                <option>가전</option>
                <option>식품</option>
            </select>
        </div>
        <div>
            <div class="categoryBar">
                <router-link :to="{ path: '/CategoryAll' }" class="category">전체</router-link>
                <router-link :to="{ path: '/CategoryCloth' }" class="category">의류</router-link>
                <router-link :to="{ path: '/CategoryJewelry' }" class="category">주얼리</router-link>
                <router-link :to="{ path: '/CategoryHomeAppliances' }" class="category">가전</router-link>
                <router-link :to="{ path: '/CategoryFood' }" class="category">식품</router-link>
            </div>
            <div>전체페이지</div>
        </div>
        <div class="cardWrapper">
            <div class="cardWrap" v-for="(item, index) in getUsers" :key="index">
                <div class="imgWrapper">
                    <router-link :to="{ path: `/productDetail/${item.id}` }">
                        <img :src="'http://192.168.0.4/resources/uploads/' + item.salesImageName" style="width: 194px; height: 194px;">
                    </router-link>
                </div>
                <div>
                    <div>
                        <router-link :to="{ path: `/productDetail/${item.id}` }">{{ item.salesName }}</router-link>
                    </div>
                    <div>
                        <span>{{ item.salesPrice }}원</span>
                        <span>{{ item.salesDate }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
    data() {
        return {
            selectedCategory: ''
        };
    },
    methods: {
        handleCategoryChange() {
            switch (this.selectedCategory) {
                case '의류':
                    this.$router.push('/CategoryCloth');
                    break;
                case '주얼리':
                    this.$router.push('/CategoryJewelry');
                    break;
                case '가전':
                    this.$router.push('/CategoryHomeAppliances');
                    break;
                case '식품':
                    this.$router.push('/CategoryFood');
                    break;
                default:
                    this.$router.push('/CategoryAll');
                    break;
            }
        }
    },
    mounted() {
        switch (this.$route.path) {
            case '/CategoryCloth':
                this.selectedCategory = '의류';
                break;
            case '/CategoryJewelry':
                this.selectedCategory = '주얼리';
                break;
            case '/CategoryHomeAppliances':
                this.selectedCategory = '가전';
                break;
            case '/CategoryFood':
                this.selectedCategory = '식품';
                break;
            default:
                this.selectedCategory = '전체';
                break;
        }
    }
});
</script>

<style scoped>
.categoryBar {
    display: flex;
    justify-content: space-between;
    border: 0.5px solid gray;
    height: 60px;
    margin-top: 4%;
    margin-bottom: 4%;
}

.category {
    display: flex;
    justify-content: center;
    flex-direction: column;
    border: 0.5px solid gray;
    width: 20%;
    text-align: center;
}
</style>
