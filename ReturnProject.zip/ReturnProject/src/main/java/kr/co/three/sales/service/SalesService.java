package kr.co.three.sales.service;

import kr.co.three.sales.dto.SalesDTO;

public interface SalesService {

//	판매 등록
	int enrollSales(SalesDTO sales);
}
